plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.jarvis.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.jarvis.app"; minSdk = 30; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("ai.picovoice:porcupine-android:3.0.2")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
