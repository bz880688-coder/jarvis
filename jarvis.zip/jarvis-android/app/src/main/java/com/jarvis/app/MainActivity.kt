package com.jarvis.app
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        val keys = listOf("pico" to "Picovoice AccessKey", "claude" to "Anthropic API key", "eleven" to "ElevenLabs API key", "voice" to "ElevenLabs voice ID")
        val fields = keys.map { (k, h) -> EditText(this).apply { hint = h; setText(Brain.pref(this@MainActivity, k)) }.also { col.addView(it) } }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        btn("Save keys") { getSharedPreferences("j", 0).edit().apply { keys.forEachIndexed { i, p -> putString(p.first, fields[i].text.toString().trim()) } }.apply() }
        btn("Grant permissions") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CALL_PHONE), 1) }
        btn("Notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("Display over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("Start JARVIS") { startForegroundService(Intent(this, JarvisService::class.java)) }
        btn("Stop") { stopService(Intent(this, JarvisService::class.java)) }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
