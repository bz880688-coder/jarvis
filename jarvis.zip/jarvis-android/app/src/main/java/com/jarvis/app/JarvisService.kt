package com.jarvis.app
import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.speech.*
import ai.picovoice.porcupine.*
import org.json.JSONObject
import kotlin.concurrent.thread

class JarvisService : Service() {
    private var porcupine: PorcupineManager? = null
    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    companion object { var instance: JarvisService? = null }

    override fun onBind(i: Intent?) = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        instance = this
        val ch = "jarvis"
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, "JARVIS", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, ch).setContentTitle("JARVIS listening").setSmallIcon(android.R.drawable.ic_btn_speak_now).build(),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (porcupine == null) {
            porcupine = PorcupineManager.Builder().setAccessKey(Brain.pref(this, "pico"))
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS).build(this) { main.post { listen() } }
        }
        porcupine?.start()
        return START_STICKY
    }

    private fun listen() {
        porcupine?.stop()                       // free the mic for SpeechRecognizer
        val sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle) { sr.destroy(); handle(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()) }
            override fun onError(e: Int) { sr.destroy(); porcupine?.start() }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}; override fun onPartialResults(p: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
    }

    private fun handle(text: String?) {
        if (text == null) { porcupine?.start(); return }
        thread {
            val r = try { Brain.ask(this, text) } catch (e: Exception) { JSONObject().put("say", "My connection has failed, sir.") }
            speak(r.optString("say"))
            r.optJSONObject("action")?.let { act(it) }
            main.post { porcupine?.start() }
        }
    }

    /** Called by AlertListener too. Runs on a background thread. */
    fun speak(t: String) {
        val f = try { Brain.voice(this, t) } catch (e: Exception) { null } ?: return
        val done = java.util.concurrent.CountDownLatch(1)
        main.post {
            player?.release()
            player = MediaPlayer().apply { setDataSource(f.path); prepare(); setOnCompletionListener { done.countDown() }; start() }
        }
        done.await()
    }

    private fun act(a: JSONObject) {
        val v = a.optString("value")
        val i = when (a.optString("type")) {
            "call" -> Intent(Intent.ACTION_CALL, Uri.parse("tel:$v"))
            "url" -> Intent(Intent.ACTION_VIEW, Uri.parse(v))
            "app" -> packageManager.getLaunchIntentForPackage(v)
            else -> null
        } ?: return
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onDestroy() { porcupine?.delete(); instance = null; super.onDestroy() }
}
