package com.jarvis.app
import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Brain {
    private val http = OkHttpClient()
    private val history = JSONArray()
    fun pref(c: Context, k: String) = c.getSharedPreferences("j", 0).getString(k, "") ?: ""

    /** Returns JSON: {"say":"...","action":{"type":"call|sms|url|app","value":"..."}|null} */
    fun ask(c: Context, text: String): JSONObject {
        history.put(JSONObject().put("role", "user").put("content", text))
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 400)
            .put("system", "You are J.A.R.V.I.S., a dry British butler AI on the user's Android phone. Reply ONLY JSON: {\"say\":\"<under 40 words>\",\"action\":null or {\"type\":\"call|url|app\",\"value\":\"number | https url | android package name\"}}. Address the user as sir. Never claim to have read data you were not given.")
            .put("messages", history)
        val r = http.newCall(Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", pref(c, "claude")).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()).execute()
        val out = JSONObject(r.body!!.string()).getJSONArray("content").getJSONObject(0).getString("text")
        history.put(JSONObject().put("role", "assistant").put("content", out))
        if (history.length() > 12) history.remove(0).also { history.remove(0) }
        return JSONObject(out.replace("```json", "").replace("```", "").trim())
    }

    /** ElevenLabs TTS -> mp3 file. */
    fun voice(c: Context, text: String): File? {
        val vid = pref(c, "voice").ifBlank { "BxoyaO1xuQUNkP2tJIrR" }
        val b = JSONObject().put("text", text).put("model_id", "eleven_turbo_v2_5")
        val r = http.newCall(Request.Builder().url("https://api.elevenlabs.io/v1/text-to-speech/$vid")
            .header("xi-api-key", pref(c, "eleven"))
            .post(b.toString().toRequestBody("application/json".toMediaType())).build()).execute()
        if (!r.isSuccessful) return null
        return File(c.cacheDir, "say.mp3").also { it.writeBytes(r.body!!.bytes()) }
    }
}
