package com.jarvis.app
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlin.concurrent.thread

/** Speaks missed calls and new messages. Needs "Notification access" enabled for JARVIS. */
class AlertListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val cat = sbn.notification.category
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val line = when (cat) {
            Notification.CATEGORY_MISSED_CALL, "missed_call" -> "Sir, you missed a call from $title."
            Notification.CATEGORY_MESSAGE -> "New message from $title: $text"
            else -> return                       // ignore everything else
        }
        thread { JarvisService.instance?.speak(line.take(200)) }
    }
}
