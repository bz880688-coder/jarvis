# JARVIS Android app (starter, untested)

## Setup
1. Install Android Studio. File > New Project > Empty Views Activity, package `com.jarvis.app`, min SDK 29, Kotlin.
2. Replace/add the files from this folder (manifest, 4 Kotlin files, dependencies from `deps.txt` into app/build.gradle.kts).
3. Get keys:
   - Picovoice AccessKey (free): console.picovoice.ai. Built-in wake word "Jarvis" is used.
   - Anthropic API key: console.anthropic.com (billed separately from claude.ai).
   - ElevenLabs API key; voice ID BxoyaO1xuQUNkP2tJIrR (check it is available to your account).
4. Run on your Redmi Note 14 5G (enable Developer options > USB debugging).
5. In the app: paste the 3 keys, Save, grant permissions, tap "Notification access" and enable JARVIS, tap Start.

## Xiaomi / HyperOS must-dos (or Android kills the service)
- Settings > Apps > JARVIS > Autostart ON; Battery saver = No restrictions.
- Lock the app in Recents.
- Allow "Display over other apps" (needed to open apps from the background).

## Limits
- Reading notification text is allowed via Notification access. Missed calls arrive as notifications from the dialer.
- Android will not let any app silently toggle most system settings; open the settings screen instead.
- Always-on mic uses battery. Nothing here has been compiled or tested; expect small fixes.
